<?php
session_start();
if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$student_id = $_SESSION['student'];
$student_name = $_SESSION['student_name'];

if (!isset($_GET['subject']) || !isset($_GET['test'])) {
    echo "Subject or test number not specified.";
    exit();
}

$subject = strtolower(trim($_GET['subject']));
$test_number = (int)$_GET['test'];

// Check if already attempted
$check = $conn->prepare("SELECT id FROM test_attempts WHERE student_id = ? AND subject = ? AND test_number = ?");
$check->bind_param("isi", $student_id, $subject, $test_number);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    echo "<h3>You have already attempted $subject Test $test_number.</h3>";
    exit();
}
$check->close();

// Fetch and shuffle questions (not options)
$stmt = $conn->prepare("SELECT id, question, option1, option2, option3, option4 FROM tests WHERE subject = ? AND test_number = ?");
$stmt->bind_param("si", $subject, $test_number);
$stmt->execute();
$result = $stmt->get_result();

$questions = [];
while ($row = $result->fetch_assoc()) {
    $options = [
        1 => $row['option1'],
        2 => $row['option2'],
        3 => $row['option3'],
        4 => $row['option4']
    ];

    $ordered_options = [];
    foreach ($options as $key => $value) {
        $ordered_options[] = ['key' => $key, 'value' => $value];
    }

    $questions[] = [
        'id' => $row['id'],
        'question' => $row['question'],
        'options' => $ordered_options
    ];
}
$stmt->close();

if (empty($questions)) {
    echo "<h3>No questions available for $subject Test $test_number.</h3>";
    exit();
}

shuffle($questions); // Shuffle only questions
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= ucfirst($subject) ?> - Test <?= $test_number ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f1f5f9;
      padding: 20px;
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }
    .layout {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
    }
    .test-container {
      flex: 1;
      min-width: 0;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      padding: 30px;
    }
    .sidebar {
      width: 200px;
      background-color: #fff;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 0 8px rgba(0, 0, 0, 0.08);
      font-size: 14px;
      height: fit-content;
    }
    .sidebar h3 {
      margin-top: 0;
      text-align: center;
      color: #333;
    }
    .q-status {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      justify-content: center;
      margin-top: 10px;
    }
    .q-box {
      width: 30px;
      height: 30px;
      background-color: #f8d7da;
      color: #000;
      border-radius: 5px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      cursor: default;
    }
    .q-box.answered {
      background-color: #d4edda;
    }
    .question-box {
      margin-bottom: 30px;
      border-left: 4px solid #3498db;
      padding-left: 15px;
    }
    .question-box p {
      font-weight: bold;
      margin-bottom: 10px;
      color: #34495e;
    }
    .option-label {
      display: block;
      background: #f1f1f1;
      padding: 10px 15px;
      border-radius: 8px;
      margin: 6px 0;
      cursor: pointer;
      transition: background 0.2s ease-in-out;
    }
    .option-label:hover {
      background-color: #dceefb;
    }
    input[type="radio"] {
      margin-right: 8px;
    }
    .submit-btn {
      padding: 10px 20px;
      background-color: #2ecc71;
      border: none;
      border-radius: 8px;
      color: white;
      font-size: 16px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .submit-btn:hover {
      background-color: #27ae60;
    }
    .nav-buttons {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      gap: 10px;
    }
    #fixedSubmitBtn {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #e74c3c;
    }
    .timer {
      font-size: 18px;
      color: red;
      text-align: right;
      margin-bottom: 15px;
      font-weight: bold;
    }
  </style>
</head>
<body>
<h2><?= ucfirst($subject) ?> - Test <?= $test_number ?></h2>
<div class="layout">
  <div class="test-container">
    <div class="timer">Time Left: <span id="timer">00:00</span></div>
    <form id="testForm" action="test_submit.php" method="POST">
      <input type="hidden" name="subject" value="<?= htmlspecialchars($subject) ?>">
      <input type="hidden" name="test_number" value="<?= $test_number ?>">
      <input type="hidden" id="totalQuestions" value="<?= count($questions) ?>">
      <?php foreach ($questions as $index => $q): ?>
        <div class="question-box" id="question-<?= $index ?>" style="<?= $index === 0 ? '' : 'display:none;' ?>">
          <p><strong>Q<?= $index + 1 ?>:</strong> <?= htmlspecialchars($q['question']) ?></p>
          <?php foreach ($q['options'] as $opt): ?>
            <label class="option-label">
              <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $opt['key'] ?>" data-question="<?= $index ?>">
              <?= htmlspecialchars($opt['value']) ?>
            </label>
          <?php endforeach; ?>
        </div>
      <?php endforeach; ?>
      <div class="nav-buttons">
        <button type="button" id="prevBtn" class="submit-btn">Previous</button>
        <button type="button" id="nextBtn" class="submit-btn">Next</button>
      </div>
    </form>
  </div>
  <div class="sidebar">
    <h3>Question Status</h3>
    <div class="q-status" id="questionStatusSidebar">
      <?php foreach ($questions as $index => $q): ?>
        <div class="q-box" id="qbox-<?= $index ?>"><?= $index + 1 ?></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<button id="fixedSubmitBtn" class="submit-btn">Submit Test</button>
<script>
  history.pushState(null, null, location.href);
  window.onpopstate = function () { history.go(1); };
  let warningCount = 0;
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      warningCount++;
      if (warningCount === 1) {
        alert("⚠️ Do not switch tabs or minimize the screen. Next time, the test will be submitted.");
      } else {
        alert("❌ Test submitted due to screen switch.");
        clearInterval(intervalId);
        document.getElementById("testForm").submit();
      }
    }
  });
  const totalQuestions = parseInt(document.getElementById("totalQuestions").value);
  let currentQuestion = 0;
  let totalTimeInSeconds = totalQuestions * 60;
  let intervalId;
  const timerDisplay = document.getElementById("timer");
  const nextBtn = document.getElementById("nextBtn");
  const prevBtn = document.getElementById("prevBtn");
  const fixedSubmitBtn = document.getElementById("fixedSubmitBtn");
  function updateTimer() {
    const min = Math.floor(totalTimeInSeconds / 60).toString().padStart(2, '0');
    const sec = (totalTimeInSeconds % 60).toString().padStart(2, '0');
    timerDisplay.textContent = `${min}:${sec}`;
    if (totalTimeInSeconds === 0) {
      clearInterval(intervalId);
      alert("⏰ Time's up! Test will be submitted.");
      document.getElementById("testForm").submit();
    } else {
      totalTimeInSeconds--;
    }
  }
  function showQuestion(index) {
    for (let i = 0; i < totalQuestions; i++) {
      document.getElementById("question-" + i).style.display = "none";
    }
    document.getElementById("question-" + index).style.display = "block";
    prevBtn.style.display = index > 0 ? 'inline-block' : 'none';
    nextBtn.style.display = index < totalQuestions - 1 ? 'inline-block' : 'none';
  }
  nextBtn.addEventListener("click", () => {
    if (currentQuestion < totalQuestions - 1) {
      currentQuestion++;
      showQuestion(currentQuestion);
    }
  });
  prevBtn.addEventListener("click", () => {
    if (currentQuestion > 0) {
      currentQuestion--;
      showQuestion(currentQuestion);
    }
  });
  fixedSubmitBtn.addEventListener("click", () => {
    if (confirm("Are you sure you want to submit the test?")) {
      document.getElementById("testForm").submit();
    }
  });
  document.querySelectorAll('input[type="radio"]').forEach(radio => {
    radio.addEventListener("change", function () {
      const qIndex = parseInt(this.getAttribute("data-question"));
      document.getElementById("qbox-" + qIndex).classList.add("answered");
    });
  });
  ["keydown", "keypress", "keyup"].forEach(evt => {
    document.addEventListener(evt, e => e.preventDefault());
  });
  document.addEventListener("contextmenu", e => e.preventDefault());
  function openFullscreen() {
    let elem = document.documentElement;
    if (elem.requestFullscreen) elem.requestFullscreen();
    else if (elem.webkitRequestFullscreen) elem.webkitRequestFullscreen();
    else if (elem.msRequestFullscreen) elem.msRequestFullscreen();
  }
  function exitFullscreen() {
    if (document.exitFullscreen) document.exitFullscreen();
    else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    else if (document.msExitFullscreen) document.msExitFullscreen();
  }
  window.onload = function () {
    openFullscreen();
    showQuestion(0);
    updateTimer();
    intervalId = setInterval(updateTimer, 1000);
  };
  document.getElementById("testForm").addEventListener("submit", () => {
    exitFullscreen();
  });
</script>
</body>
</html>
