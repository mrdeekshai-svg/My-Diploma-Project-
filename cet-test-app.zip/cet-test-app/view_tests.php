<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

// Fetch distinct subjects
$subjectResult = $conn->query("SELECT DISTINCT subject FROM tests ORDER BY subject");

$selected_subject = isset($_POST['subject']) ? $_POST['subject'] : null;
$testResult = null;

if ($selected_subject) {
    $stmt = $conn->prepare("SELECT test_number, COUNT(*) AS total_questions 
                            FROM tests 
                            WHERE subject = ? 
                            GROUP BY test_number 
                            ORDER BY test_number DESC");
    $stmt->bind_param("s", $selected_subject);
    $stmt->execute();
    $testResult = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Tests by Subject</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f4f4f4;
        }
        h2 {
            text-align: center;
        }
        form {
            text-align: center;
            margin-bottom: 20px;
        }
        select, button {
            padding: 8px 15px;
            font-size: 16px;
        }
        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th {
            background-color: #333;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .btn {
            padding: 5px 10px;
            background: #007bff;
            color: white;
            border-radius: 4px;
            text-decoration: none;
        }
        .btn:hover {
            background: #0056b3;
        }
        
    </style>
</head>
<body>

<h2>View Uploaded Tests by Subject</h2>

<form method="POST" action="">
    <label for="subject">Select Subject:</label>
    <select name="subject" required>
        <option value="">-- Choose --</option>
        <?php while ($row = $subjectResult->fetch_assoc()): ?>
            <option value="<?php echo $row['subject']; ?>" <?php echo ($selected_subject == $row['subject']) ? 'selected' : ''; ?>>
                <?php echo ucfirst($row['subject']); ?>
            </option>
        <?php endwhile; ?>
    </select>
    <button type="submit">View</button>
</form>

<?php if ($testResult && $testResult->num_rows > 0): ?>
    <table>
        <tr>
            <th>Subject</th>
            <th>Test Number</th>
            <th>Total Questions</th>
            <th>Action</th>
        </tr>
        <?php while($row = $testResult->fetch_assoc()): ?>
        <tr>
            <td><?php echo ucfirst($selected_subject); ?></td>
            <td><?php echo $row['test_number']; ?></td>
            <td><?php echo $row['total_questions']; ?></td>
            <td>
                <a class="btn" href="view_submissions.php?subject=<?php echo $selected_subject; ?>&test_number=<?php echo $row['test_number']; ?>">
                    View Submissions
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php elseif ($selected_subject): ?>
    <p style="text-align: center;">No tests found for <strong><?php echo ucfirst($selected_subject); ?></strong>.</p>
<?php endif; ?>
<div style="text-align: left; margin-bottom: 10px;">
    <a href="dashboard_admin.php" style="
        display: inline-block;
        padding: 8px 15px;
        background-color: #6c757d;
        color: white;
        text-decoration: none;
        border-radius: 4px;
        font-weight: bold;
    ">← Back to Dashboard</a>
</div>

</body>
</html>
