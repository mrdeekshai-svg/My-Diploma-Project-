<?php
session_start();
if (!isset($_SESSION['admin']) || !$_SESSION['is_super_admin']) {
    header("Location: dashboard_admin.php");
    exit();
}

include 'db.php';

// Handle new admin creation
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['new_username'], $_POST['new_password'])) {
    $username = $_POST['new_username'];
    $password = password_hash($_POST['new_password'], PASSWORD_DEFAULT); // Hash password

    $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->close();

    header("Location: manage_admins.php");
    exit();
}

// Handle delete admin
if (isset($_GET['delete'])) {
    $delete_id = intval($_GET['delete']);
    if ($delete_id != 1) { // Don't allow deletion of super admin
        $conn->query("DELETE FROM admins WHERE id = $delete_id");
    }
    header("Location: manage_admins.php");
    exit();
}

// Fetch all admins
$result = $conn->query("SELECT * FROM admins");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Admins</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            padding: 20px;
        }
        h2 {
            text-align: center;
        }
        .form-container {
            width: 40%;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 6px;
            box-shadow: 0 0 5px #ccc;
        }
        table {
            width: 90%;
            margin: 30px auto;
            background: white;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background: #333;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            text-decoration: none;
            color: white;
            border-radius: 4px;
        }
        .btn-delete {
            background: #dc3545;
        }
        .btn-back {
            display: inline-block;
            background: #6c757d;
            margin-bottom: 15px;
        }
        .btn-edit {
            background: #28a745;
        }
    </style>
</head>
<body>

<div style="text-align: left;">
    <a href="dashboard_admin.php" class="btn btn-back">← Back to Dashboard</a>
</div>

<h2>Manage Admins</h2>

<div class="form-container">
    <h3>Add New Admin</h3>
    <form method="POST">
        <input type="text" name="new_username" placeholder="Username" required style="width: 100%; padding: 10px; margin-bottom: 10px;">
        <input type="password" name="new_password" placeholder="Password" required style="width: 100%; padding: 10px; margin-bottom: 10px;">
        <button type="submit" style="padding: 10px 15px; background: #007bff; color: white; border: none;">Add Admin</button>
    </form>
</div>

<?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Action</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['username']); ?></td>
            <td>
                <?php if ($row['id'] != 1): ?>
                    <a class="btn btn-delete" href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    <a class="btn btn-edit" href="edit_admin_user.php?id=<?= $row['id']; ?>">Edit</a>
                <?php else: ?>
                    Super Admin
                <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php endif; ?>

</body>
</html>
