<?php
session_start();

// Restrict access to logged-in admin
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // Your database connection file

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = strtolower(trim($_POST['subject']));
    $display_name = trim($_POST['display_name']);
    $upload_dir = "uploads/";

    $original_name = basename($_FILES["paper"]["name"]);
    $unique_prefix = time() . "_" . rand(1000,9999) . "_";
    $file_name = $unique_prefix . $original_name;
    $target_file = $upload_dir . $file_name;
    $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    $allowed = ['pdf', 'doc', 'docx', 'png', 'jpg', 'jpeg'];

    if (!in_array($file_type, $allowed)) {
        echo "<script>alert('Only PDF, DOC, DOCX, JPG, PNG files are allowed.');</script>";
    } else {
        if (move_uploaded_file($_FILES["paper"]["tmp_name"], $target_file)) {
            $stmt = $conn->prepare("INSERT INTO papers (subject, display_name, file_name, uploaded_at) VALUES (?, ?, ?, NOW())");
            $stmt->bind_param("sss", $subject, $display_name, $file_name);
            if ($stmt->execute()) {
                echo "<script>alert('Paper uploaded successfully.');</script>";
            } else {
                echo "<script>alert('Database error: " . $stmt->error . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Error uploading the file.');</script>";
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $file_name = $_GET['delete'];
    $file_path = "uploads/" . $file_name;

    $stmt = $conn->prepare("DELETE FROM papers WHERE file_name = ?");
    $stmt->bind_param("s", $file_name);
    $stmt->execute();
    $stmt->close();

    if (file_exists($file_path)) {
        unlink($file_path);
    }

    echo "<script>alert('Paper deleted successfully.'); window.location='uploadpaper.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload CET Paper</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(to right, #f0f4ff, #dfe9f3);
            padding: 40px;
        }
        .upload-container {
            background-color: #fff;
            padding: 30px 40px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            max-width: 500px;
            margin: auto;
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #555;
        }
        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        button {
            width: 100%;
            padding: 12px;
            background-color: #4a90e2;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }
        button:hover {
            background-color: #357ac8;
        }
        table {
            margin: 40px auto;
            width: 90%;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 6px 14px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px 16px;
            text-align: center;
            border-bottom: 1px solid #eee;
        }
        th {
            background-color: #4a90e2;
            color: white;
        }
        tr:hover {
            background-color: #f0f8ff;
        }
        .btn {
            padding: 6px 12px;
            border-radius: 5px;
            color: white;
            text-decoration: none;
        }
        .btn-view {
            background-color: #2ecc71;
        }
        .btn-delete {
            background-color: #e74c3c;
        }
        .btn-view:hover {
            background-color: #27ae60;
        }
        .btn-delete:hover {
            background-color: #c0392b;
        }
        .back-button {
            margin: 20px;
        }
        .back-button a {
            background-color: #4e54c8;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .back-button a:hover {
            background-color: #3b40a4;
        }
    </style>
    <script>
        function confirmDelete(file) {
            if (confirm("Are you sure you want to delete this paper?")) {
                window.location.href = "uploadpaper.php?delete=" + encodeURIComponent(file);
            }
        }
    </script>
</head>
<body>
<div class="upload-container">
    <h2>Upload CET Paper</h2>
    <form method="post" enctype="multipart/form-data">
        <label>Subject:</label>
        <input type="text" name="subject" required>

        <label>Display File Name (what students will see):</label>
        <input type="text" name="display_name" required>

        <label>Select File:</label>
        <input type="file" name="paper" required>

        <button type="submit">Upload</button>
    </form>
</div>

<h2 style="text-align:center; margin-top: 60px;">Uploaded Papers</h2>
<table>
    <tr>
        <th>ID</th>
        <th>Subject</th>
        <th>Display Name</th>
        <th>Uploaded At</th>
        <th>Actions</th>
    </tr>
    <?php
    $result = $conn->query("SELECT * FROM papers ORDER BY uploaded_at DESC");
    $i = 1;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $i++ . "</td>";
            echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
            echo "<td>" . htmlspecialchars($row['display_name']) . "</td>";
            echo "<td>" . $row['uploaded_at'] . "</td>";
            echo "<td>
                    <a class='btn btn-view' href='uploads/{$row['file_name']}' target='_blank'>View</a>
                    &nbsp;
                    <a class='btn btn-delete' href='#' onclick=\"confirmDelete('{$row['file_name']}')\">Delete</a>
                  </td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No papers uploaded yet.</td></tr>";
    }
    ?>
</table>

<div class="back-button">
    <a href="dashboard_admin.php">⬅ Back to Admin Dashboard</a>
</div>

</body>
</html>