<?php
session_start();
if (!isset($_SESSION['admin']) || !$_SESSION['is_super_admin']) {
    header("Location: dashboard_admin.php");
    exit();
}

include 'db.php';

$admin_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($admin_id <= 1) {
    echo "Cannot edit Super Admin.";
    exit();
}

$stmt = $conn->prepare("SELECT username FROM admins WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = $_POST['username'];
    $new_password = $_POST['password'];
    
    if (!empty($new_username) && !empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $update = $conn->prepare("UPDATE admins SET username = ?, password = ? WHERE id = ?");
        $update->bind_param("ssi", $new_username, $hashed_password, $admin_id);
        $update->execute();
        $update->close();

        echo "<script>alert('Admin updated successfully!'); window.location.href='manage_admins.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin</title>
</head>
<body>
<h2>Edit Admin ID <?= $admin_id ?></h2>
<form method="post">
    <label>Username:</label><br>
    <input type="text" name="username" value="<?= htmlspecialchars($username) ?>" required><br><br>

    <label>New Password:</label><br>
    <input type="password" name="password" required><br><br>

    <input type="submit" value="Update">
</form>
</body>
</html>
