<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

// Get all subjects
$subjectList = $conn->query("SELECT name FROM subjects");

// Subject from GET
$subject = $_GET['subject'] ?? '';

// Fetch tests only if subject selected
$tests = null;
if ($subject) {
    $stmt = $conn->prepare("SELECT DISTINCT test_number FROM tests WHERE subject=? ORDER BY test_number");
    $stmt->bind_param("s", $subject);
    $stmt->execute();
    $tests = $stmt->get_result();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage CET Tests</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form.select-form {
            margin-bottom: 30px;
            background: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            display: inline-block;
            box-shadow: 0 0 5px rgba(0,0,0,0.1);
        }

        select {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .test-list {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }

        .test-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .test-card h3 {
            margin: 0 0 10px;
        }

        .test-card a {
            display: inline-block;
            margin-top: 5px;
            text-decoration: none;
            color: #2c3e50;
            font-weight: bold;
        }

        .test-card a:hover {
            color: #2980b9;
        }

        .new-test {
            margin-top: 40px;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            max-width: 400px;
            box-shadow: 0 0 8px rgba(0,0,0,0.1);
        }

        input[type="number"], button {
            padding: 10px;
            margin-top: 5px;
            width: 100%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            background-color: #27ae60;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #219150;
        }
    </style>
</head>
<body>

<h2>Manage CET Tests</h2>

<!-- Subject Selection -->
<form method="GET" class="select-form">
    <label for="subject">Select Subject:</label>
    <select name="subject" id="subject" onchange="this.form.submit()" required>
        <option value="">-- Choose Subject --</option>
        <?php while($row = $subjectList->fetch_assoc()): ?>
            <option value="<?= $row['name'] ?>" <?= ($row['name'] === $subject) ? 'selected' : '' ?>>
                <?= ucfirst($row['name']) ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<?php if ($subject): ?>
    <h3>Subject: <?= ucfirst($subject) ?></h3>

    <div class="test-list">
        <?php if ($tests && $tests->num_rows > 0): ?>
            <?php while($row = $tests->fetch_assoc()): ?>
                <div class="test-card">
                    <h3>Test <?= $row['test_number'] ?></h3>
                    <a href="view_questions.php?subject=<?= urlencode($subject) ?>&test=<?= $row['test_number'] ?>">👁 View Questions</a><br>
                    <a href="upload_test.php?subject=<?= urlencode($subject) ?>&test=<?= $row['test_number'] ?>">➕ Upload Questions</a>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No tests found for this subject. Create one below!</p>
        <?php endif; ?>
    </div>

    <div class="new-test">
        <h3>Create New Test</h3>
        <form method="get" action="upload_test.php">
            <input type="hidden" name="subject" value="<?= htmlspecialchars($subject) ?>">
            <label for="test">Test Number:</label>
            <input type="number" name="test" id="test" required min="1">
            <button type="submit">Create & Upload Questions</button>
        </form>
    </div>
<?php endif; ?>

</body>
</html>
