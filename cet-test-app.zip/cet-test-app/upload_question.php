<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

$subject = $_GET['subject'] ?? '';
$test_number = $_GET['test'] ?? '';
if (!$subject || !$test_number) die("Invalid access.");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct = strtoupper($_POST['correct']);

    $stmt = $conn->prepare("INSERT INTO tests (subject, test_number, question, option1, option2, option3, option4, correct_option)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sissssss", $subject, $test_number, $question, $option1, $option2, $option3, $option4, $correct);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Question uploaded successfully!');</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Questions - <?= $subject ?> (Test <?= $test_number ?>)</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 20px; }
        .box {
            max-width: 600px; margin: auto; background: white;
            padding: 25px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label { display: block; margin-top: 15px; font-weight: bold; }
        input, textarea, select {
            width: 100%; padding: 10px; margin-top: 5px;
            border: 1px solid #ccc; border-radius: 5px;
        }
        button {
            margin-top: 20px; padding: 10px 15px; background: #3498db; color: white;
            border: none; border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="box">
        <h2><?= ucfirst($subject) ?> - Upload Question (Test <?= $test_number ?>)</h2>
        <form method="POST">
            <label>Question:</label>
            <textarea name="question" rows="3" required></textarea>

            <label>Option A:</label>
            <input type="text" name="option1" required>

            <label>Option B:</label>
            <input type="text" name="option2" required>

            <label>Option C:</label>
            <input type="text" name="option3" required>

            <label>Option D:</label>
            <input type="text" name="option4" required>

            <label>Correct Option (A/B/C/D):</label>
            <input type="text" name="correct" maxlength="1" required>

            <button type="submit">Upload Question</button>
        </form>
    </div>
</body>
</html>
