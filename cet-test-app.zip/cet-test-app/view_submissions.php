<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

// Fetch test attempts with subject + test_number + student info
$query = "
    SELECT ts.student_id, s.name AS student_name, ts.subject, ts.test_number, ts.score, 
           ts.answered_questions, ts.total_questions, ts.attempted_at
    FROM test_attempts ts
    JOIN students s ON ts.student_id = s.id
    ORDER BY ts.subject, ts.test_number, ts.attempted_at DESC
";

$result = $conn->query($query);
$submissions = [];

// Group by subject → test_number
while ($row = $result->fetch_assoc()) {
    $subject = ucfirst($row['subject']);
    $test_number = $row['test_number'];
    $submissions[$subject][$test_number][] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Submissions</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(to right, #eef2f5, #dce3ec);
            padding: 20px;
            margin: 0;
            color: #333;
        }

        h2, h3, h4 {
            text-align: center;
            color: #2c3e50;
            margin-top: 0;
        }

        .subject-section {
            margin: 40px auto;
            width: 95%;
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
            transition: transform 0.2s ease-in-out;
        }

        .subject-section:hover {
            transform: scale(1.01);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border: 1px solid #e1e4e8;
            font-size: 15px;
        }

        th {
            background-color: #007bff;
            color: white;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        tr:nth-child(even) {
            background-color: #f4f7fb;
        }

        tr:hover {
            background-color: #d9eaff;
            transition: 0.2s;
        }

        .back-btn {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 20px;
            background-color: #2ecc71;
            color: white;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 14px;
            transition: background 0.3s, transform 0.2s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .back-btn:hover {
            background-color: #27ae60;
            transform: scale(1.05);
        }

        @media screen and (max-width: 768px) {
            .subject-section {
                width: 100%;
                padding: 15px;
            }

            th, td {
                font-size: 13px;
                padding: 8px;
            }

            .back-btn {
                font-size: 13px;
                padding: 8px 16px;
            }
        }
    </style>
</head>
<body>

<h2>Student Test Submissions - Subject & Test Number Wise</h2>

<?php if (!empty($submissions)): ?>
    <?php foreach ($submissions as $subject => $tests): ?>
        <div class="subject-section">
            <h3><?= htmlspecialchars($subject) ?></h3>

            <?php foreach ($tests as $test_number => $rows): ?>
                <h4>Test Number: <?= htmlspecialchars($test_number) ?></h4>
                <table>
                    <tr>
                        <th>Student ID</th>
                        <th>Student Name</th>
                        <th>Total</th>
                        <th>Attempted</th>
                        <th>Correct</th>
                        <th>Wrong</th>
                        <th>Score</th>
                        <th>Percentage</th>
                        <th>Attempted At</th>
                    </tr>
                    <?php foreach ($rows as $row): ?>
                        <?php
                            $score = $row['score'];
                            $answered = $row['answered_questions'];
                            $total = $row['total_questions'];
                            $wrong = $answered - $score;
                            $percentage = ($total > 0) ? round(($score / $total) * 100, 2) : 0;
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($row['student_id']) ?></td>
                            <td><?= htmlspecialchars($row['student_name']) ?></td>
                            <td><?= htmlspecialchars($total) ?></td>
                            <td><?= htmlspecialchars($answered) ?></td>
                            <td><?= htmlspecialchars($score) ?></td>
                            <td><?= htmlspecialchars($wrong) ?></td>
                            <td><?= htmlspecialchars($score) ?></td>
                            <td><?= $percentage ?>%</td>
                            <td><?= htmlspecialchars($row['attempted_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p style="text-align: center;">No test submissions found.</p>
<?php endif; ?>

<div style="text-align: center;">
    <a href="dashboard_admin.php" class="back-btn">← Back to Dashboard</a>
</div>

</body>
</html>
