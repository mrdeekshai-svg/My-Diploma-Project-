<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

$subject = $_GET['subject'] ?? '';
if (!$subject) {
    echo "Invalid subject selected.";
    exit();
}

// Fetch ALL questions for the subject
$stmt = $conn->prepare("SELECT * FROM tests WHERE subject = ? ORDER BY id ASC");
$stmt->bind_param("s", $subject);
$stmt->execute();
$result = $stmt->get_result();
$questions = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= ucfirst($subject) ?> Questions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f0f0;
            padding: 30px;
        }
        .question-box {
            background: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .option {
            margin: 5px 0;
        }
        .correct {
            font-weight: bold;
            color: green;
        }
        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .back-btn:hover {
            background-color: #2980b9;
        }
        .action-buttons {
            margin-top: 10px;
        }
        .edit-btn, .delete-btn {
            display: inline-block;
            padding: 6px 12px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-right: 10px;
        }
        .edit-btn {
            background-color: #f39c12;
            color: white;
        }
        .edit-btn:hover {
            background-color: #e67e22;
        }
        .delete-btn {
            background-color: #e74c3c;
            color: white;
        }
        .delete-btn:hover {
            background-color: #c0392b;
        }

        /* Print styles */
        @media print {
            .back-btn,
            .action-buttons {
                display: none !important;
            }

            body {
                background: white;
                padding: 0;
            }

            .question-box {
                page-break-inside: avoid;
                box-shadow: none;
                border: 1px solid #ccc;
            }

            h2 {
                margin-top: 0;
            }
        }
    </style>
</head>
<body>
    <a class="back-btn" href="dashboard_admin.php">← Back to Dashboard</a>
    <a class="back-btn" href="javascript:window.print()">🖨️ Print This Page</a>

    <h2><?= ucfirst($subject) ?> - All Uploaded Questions</h2>

    <?php if (count($questions) > 0): ?>
        <?php foreach ($questions as $index => $q): ?>
            <div class="question-box">
                <p><strong>Q<?= $index + 1 ?>:</strong> <?= htmlspecialchars($q['question']) ?></p>
                <div class="option">A. <?= htmlspecialchars($q['option1']) ?></div>
                <div class="option">B. <?= htmlspecialchars($q['option2']) ?></div>
                <div class="option">C. <?= htmlspecialchars($q['option3']) ?></div>
                <div class="option">D. <?= htmlspecialchars($q['option4']) ?></div>
                <div class="correct">✔ Correct Option: <?= htmlspecialchars($q['correct_option']) ?></div>

                <div class="action-buttons">
                    <a class="edit-btn" href="edit_question.php?id=<?= $q['id'] ?>">✏️ Edit</a>
                    <a class="delete-btn" href="delete_question.php?id=<?= $q['id'] ?>" onclick="return confirm('Are you sure you want to delete this question?');">🗑️ Delete</a>
                </div>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No questions uploaded yet for <strong><?= ucfirst($subject) ?></strong>.</p>
    <?php endif; ?>
</body>
</html>
