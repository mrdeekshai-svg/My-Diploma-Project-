-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2026 at 06:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cet_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'hpmplpunith16@gmail.com', '$2y$10$5PQZqPSdUzUxemcoTgbLeOhfqZkKxuhicGdd6S1EeRD3oFGirtmBC');

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

CREATE TABLE `papers` (
  `id` int(11) NOT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `subject`, `display_name`, `file_name`, `uploaded_at`) VALUES
(8, 'physics', 'Test1_Key_Ans', '1750872754_3787_1234.pdf', '2025-06-25 23:02:34'),
(9, 'chemistry', 'Test1_Key_Ans', '1750873344_4850_1234.pdf', '2025-06-25 23:12:24'),
(10, 'physics', 'Test1_Key_Ans', '1750873386_9686_1234.pdf', '2025-06-25 23:13:06'),
(11, 'physics', 'Test1_Key_Ans', '1750873397_7586_1234.pdf', '2025-06-25 23:13:17');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `password`) VALUES
(3, 'PUNITH M', 'hpmplpunith16@gmail.com', '$2y$10$ZfLHtD8pHV1ksEju1HLAIe3F0cwXIJ6AnBE2gO6bp3f2d5cO4yW0W');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `status`) VALUES
(1, 'PHYSICS', 'active'),
(2, 'chemistry', 'active'),
(3, 'biology', 'active'),
(4, 'maths', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `question` text NOT NULL,
  `option1` text NOT NULL,
  `option2` text NOT NULL,
  `option3` text NOT NULL,
  `option4` text NOT NULL,
  `correct_option` tinyint(4) NOT NULL CHECK (`correct_option` between 1 and 4),
  `test_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `subject`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_option`, `test_number`) VALUES
(5, 'physics', 'What is the SI unit of force?', 'Newton', 'Joule', 'Pascal', '0', 1, 1),
(6, 'PHYSICS', 'The acceleration of an object is the rate of change of:', 'Force', 'Momentum', 'Velocity', 'Displacement', 3, 1),
(7, 'PHYSICS', 'A body is said to be in uniform motion if it:', 'Moves in a circular path', 'Has constant acceleration', 'Covers equal distances in equal intervals of time', 'Changes direction continuously', 3, 1),
(8, 'physics', 'The SI unit of electric field is:', 'Volt', 'Volt/meter', 'Newton', 'Newton/Coulomb', 4, 1),
(9, 'PHYSICS', 'Electric field inside a conductor is', 'Zero', ' Infinite', ' Depends on shape', ' Depends on shape', 1, 1),
(10, 'PHYSICS', 'Ohm’s law is valid for:', 'Semiconductor', 'Electrolyte', 'Metallic conductor', 'Vacuum tube', 3, 1),
(11, 'PHYSICS', 'The resistance of a wire is directly proportional to:', 'Length', ' Area', 'Temperature', 'Volume', 1, 1),
(12, 'physics', 'What is the SI unit of force?', 'Newton', 'Pascal', 'Joule', 'Watt', 1, 1),
(13, 'physics', 'Which of the following is a vector quantity?', 'Speed', 'Mass', 'Displacement', 'Temperature', 3, 1),
(14, 'physics', 'Acceleration due to gravity on Earth is approximately?', '9.8 m/s²', '10 m/s²', '8.9 m/s²', '9.2 m/s²', 1, 1),
(15, 'physics', 'Who discovered the law of universal gravitation?', 'Albert Einstein', 'Isaac Newton', 'Galileo Galilei', 'Nikola Tesla', 2, 1),
(16, 'physics', 'What type of lens is used to correct short-sightedness (myopia)?', 'Convex', 'Concave', 'Cylindrical', 'Plano', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `test_attempts`
--

CREATE TABLE `test_attempts` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `test_number` int(11) DEFAULT NULL,
  `score` int(11) DEFAULT NULL,
  `answered_questions` int(11) DEFAULT NULL,
  `total_questions` int(11) DEFAULT NULL,
  `attempted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `test_attempts`
--

INSERT INTO `test_attempts` (`id`, `student_id`, `subject`, `test_number`, `score`, `answered_questions`, `total_questions`, `attempted_at`) VALUES
(37, 1, 'physics', 1, 1, 6, 12, '2025-06-27 20:14:32'),
(38, 3, 'physics', 1, 3, 12, 12, '2026-02-14 22:45:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `papers`
--
ALTER TABLE `papers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_attempts`
--
ALTER TABLE `test_attempts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `papers`
--
ALTER TABLE `papers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `test_attempts`
--
ALTER TABLE `test_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
