<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php'; // DB connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Secure password

    if (!empty($name) && !empty($email) && !empty($password)) {
        $stmt = $conn->prepare("INSERT INTO students (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);
        if ($stmt->execute()) {
            // ✅ Use JS alert and redirect
            echo "<script>
                    alert('✅ Student added successfully!');
                    window.location.href = 'manage_students.php';
                  </script>";
            exit();
        } else {
            $error = "❌ Error: Could not add student.";
        }
    } else {
        $error = "⚠️ All fields are required!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add New Student</title>
    <link rel="stylesheet" href="add_students.css">
</head>
<body>
<div class="container">
    <h2>Add New Student</h2>

    <?php if (isset($error)): ?>
        <p style="color: red; font-weight: bold;"><?= $error ?></p>
    <?php endif; ?>

    <form method="POST" action="add_student.php">
        <label>Name:</label><br>
        <input type="text" name="name" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Add Student</button>
    </form>
</div>
</body>
</html>
