<?php
session_start();
if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$student_id = $_SESSION['student'];
$student_name = $_SESSION['student_name'];

$subjects = ['physics', 'chemistry', 'maths', 'biology'];
$subjectIcons = [
    'physics' => '🧲',
    'chemistry' => '⚗️',
    'maths' => '📐',
    'biology' => '🧬'
];

// Fetch test info
$testList = [];
$res = $conn->query("SELECT subject, test_number FROM tests GROUP BY subject, test_number ORDER BY subject, test_number");
while ($row = $res->fetch_assoc()) {
    $testList[strtolower($row['subject'])][] = (int)$row['test_number'];
}

// Fetch attempted tests
$attemptedTests = [];
$res2 = $conn->query("SELECT subject, test_number FROM test_attempts WHERE student_id = '$student_id'");
while ($row = $res2->fetch_assoc()) {
    $s = strtolower($row['subject']);
    $t = (int)$row['test_number'];
    $attemptedTests[$s][$t] = true;
}

// Fetch report data
$reportData = [];
$stmt = $conn->prepare("SELECT subject, test_number, score, total_questions, attempted_at FROM test_attempts WHERE student_id = ? ORDER BY subject, test_number, attempted_at DESC");
$stmt->bind_param("i", $student_id);
$stmt->execute();
$scores = $stmt->get_result();
while ($row = $scores->fetch_assoc()) {
    $subj = strtolower($row['subject']);
    $reportData[$subj][] = $row;
}
$papers = [];
$result = $conn->query("SELECT subject, display_name, file_name FROM papers ORDER BY uploaded_at DESC");

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $papers[] = [
            'subject' => $row['subject'],
            'display' => $row['display_name'],
            'file' => $row['file_name']
        ];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CET Student Dashboard</title>
    <link rel="stylesheet" href="dashboard_student.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="dashboard">
    <section class="section active" id="home">
        <h1>Welcome, <?= htmlspecialchars($student_name) ?> 👋</h1>
        <h4 style="color:green; text-align:center;">Logged in as: <?= htmlspecialchars($student_name) ?> (ID: <?= $student_id ?>)</h4>
        <p style="text-align:center; color: #555;">Use the bottom menu to navigate your dashboard.</p>
    </section>

    <section class="section" id="test">
        <h2 class="test-title">Choose a Subject & Test</h2>
        <div class="subject-grid-modern">
            <?php foreach ($subjects as $sub): ?>
                <div class="subject-card-modern" onclick="toggleTestList('<?= $sub ?>')">
                    <div class="subject-icon"><?= $subjectIcons[$sub] ?></div>
                    <div class="subject-name"><?= ucfirst($sub) ?></div>
                    <div class="test-list" id="tests-<?= $sub ?>">
                        <?php $tests = $testList[$sub] ?? []; ?>
                        <?php if (empty($tests)): ?>
                            <p class="no-test">No tests available.</p>
                        <?php else: ?>
                            <?php foreach ($tests as $tnum): ?>
                                <div class="test-box-modern">
                                    <span>Test <?= $tnum ?></span>
                                    <?php if (isset($attemptedTests[$sub][$tnum])): ?>
                                        <span class="attempted-label">Attempted</span>
                                    <?php else: ?>
                                        <a class="start-btn-modern" href="take_test.php?subject=<?= $sub ?>&test=<?= $tnum ?>">Start</a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section" id="report">
        <h2 class="report-title">Subject-wise Report</h2>
        <div class="report-subjects">
            <?php foreach ($subjects as $sub): ?>
                <button class="report-btn modern-btn" onclick="showReport('<?= $sub ?>')">
                    <?= ucfirst($sub) ?>
                </button>
            <?php endforeach; ?>
        </div>

        <?php foreach ($reportData as $sub => $entries): ?>
            <?php
                $total = 0; $correct = 0; $attempts = 0;
                foreach ($entries as $entry) {
                    $correct += $entry['score'];
                    $total += $entry['total_questions'];
                    $attempts++;
                }
                $wrong = $total - $correct;
                $percent = $total ? round(($correct / $total) * 100, 2) : 0;
                $deg = round(360 * ($percent / 100));
            ?>
            <div class="report-section modern-card" id="report-<?= $sub ?>" style="display: none;">
                <h3 class="sub-header"><?= ucfirst($sub) ?> Summary</h3>
                <div class="summary-grid">
                    <div class="report-card">Attempts <strong><?= $attempts ?></strong></div>
                    <div class="report-card">Total Questions <strong><?= $total ?></strong></div>
                    <div class="report-card">Correct Answers <strong><?= $correct ?></strong></div>
                    <div class="report-card">Wrong Answers <strong><?= $wrong ?></strong></div>
                    <div class="report-card score-card">
                        Score
                        <div class="circular-progress" style="--percent: <?= $deg ?>deg;" data-text="<?= $percent ?>%"></div>
                    </div>
                </div>

                <h3 class="sub-header">Test-wise Report</h3>
                <div class="test-grid">
                    <?php foreach ($entries as $entry): 
                        $score = $entry['score'];
                        $totalQ = $entry['total_questions'];
                        $testNum = $entry['test_number'];
                        $date = date("d M Y", strtotime($entry['attempted_at']));
                        $percentScore = round(($score / $totalQ) * 100);
                        $badgeColor = $percentScore >= 80 ? '#00b894' : ($percentScore >= 50 ? '#fdcb6e' : '#d63031');
                    ?>
                        <div class="test-card modern-shadow">
                            <div class="test-header">
                                Test <?= $testNum ?>
                                <span class="test-date"><?= $date ?></span>
                            </div>
                            <div class="test-score">Score: <?= $score ?>/<?= $totalQ ?></div>
                            <div class="test-badge" style="background-color: <?= $badgeColor ?>;"><?= $percentScore ?>%</div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </section>
<!-- 📘 CET Papers Section -->
<section class="section" id="papers">
    <h2 style="text-align: center; color: #2c3e50; margin-bottom: 20px;">📘 CET Papers</h2>
    
    <?php if (!empty($papers)): ?>
        <div class="papers-grid">
            <?php foreach ($papers as $paper): ?>
                <div class="paper-card">
                    <div class="paper-subject"><?= htmlspecialchars(ucfirst($paper['subject'])) ?></div>
                    <div class="paper-link">
                        <a href="uploads/<?= urlencode($paper['file']) ?>" target="_blank">
                            📄 <?= htmlspecialchars($paper['display']) ?>
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p style="text-align: center; color: #888;">No papers uploaded yet.</p>
    <?php endif; ?>
</section>



<!-- Bottom Nav -->
<div class="bottom-nav">
    <a class="nav-item" href="#" onclick="showSection('home')">🏠<br>Home</a>
    <a class="nav-item" href="#" onclick="showSection('test')">🧪<br>Test</a>
    <a class="nav-item" href="#" onclick="showSection('report')">📊<br>Report</a>
    <a class="nav-item" href="#" onclick="showSection('papers')">📁<br>Papers</a>
    <a class="nav-item" href="logout.php">🔓<br>Logout</a>
</div>

<!-- Scripts -->
<script>
function showSection(id) {
    document.querySelectorAll('.section').forEach(sec => sec.classList.remove('active'));
    document.getElementById(id).classList.add('active');
}
function showReport(subject) {
    document.querySelectorAll('.report-section').forEach(div => div.style.display = 'none');
    document.getElementById('report-' + subject).style.display = 'block';
    showSection('report');
}
function toggleTestList(subject) {
    const card = document.querySelector(`#tests-${subject}`).parentElement;
    card.classList.toggle('active');
}
</script>
</body>
</html>
