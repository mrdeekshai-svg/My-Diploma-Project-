<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$message = "";

// Fetch existing data
$stmt = $conn->prepare("SELECT name, email FROM students WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();

if (!$student) {
    echo "Student not found.";
    exit();
}

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newName = trim($_POST['name']);
    $newEmail = trim($_POST['email']);
    $newPassword = trim($_POST['password']);

    if (!empty($newName) && !empty($newEmail)) {
        if (!empty($newPassword)) {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $update = $conn->prepare("UPDATE students SET name = ?, email = ?, password = ? WHERE id = ?");
            $update->bind_param("sssi", $newName, $newEmail, $hashedPassword, $id);
        } else {
            $update = $conn->prepare("UPDATE students SET name = ?, email = ? WHERE id = ?");
            $update->bind_param("ssi", $newName, $newEmail, $id);
        }

        if ($update->execute()) {
            echo "<script>alert('✅ Student updated successfully!'); window.location.href='manage_students.php';</script>";
            exit();
        } else {
            $message = "❌ Error updating student.";
        }
    } else {
        $message = "⚠️ Name and Email are required.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="add_students.css">
</head>
<body>
<div class="container">
    <h2>Edit Student</h2>

    <?php if ($message): ?>
        <p style="color: red; font-weight: bold;"><?= $message ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Name:</label><br>
        <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?= htmlspecialchars($student['email']) ?>" required><br><br>

        <label>New Password (optional):</label><br>
        <input type="password" name="password" placeholder="Leave blank to keep current password"><br><br>

        <button type="submit">Update Student</button>
    </form>
</div>
</body>
</html>
