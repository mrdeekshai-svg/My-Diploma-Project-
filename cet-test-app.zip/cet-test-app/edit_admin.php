<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';
$admin_id = $_SESSION['admin'];
$message = "";

// Fetch current details
$stmt = $conn->prepare("SELECT username FROM admins WHERE id = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();

// Update details on form submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = $_POST['username'];
    $new_password = $_POST['password'];

    if (!empty($new_username) && !empty($new_password)) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        $update = $conn->prepare("UPDATE admins SET username = ?, password = ? WHERE id = ?");
        $update->bind_param("ssi", $new_username, $hashed_password, $admin_id);

        if ($update->execute()) {
            // Show JS alert and redirect
            echo "<script>
                alert('Updated successfully!');
                window.location.href = 'dashboard_admin.php';
            </script>";
            exit();
        } else {
            $message = "Update failed.";
        }

        $update->close();
    } else {
        $message = "All fields are required.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 40px;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: white;
            max-width: 400px;
            margin: 30px auto;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        label {
            font-weight: bold;
            color: #444;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        p {
            text-align: center;
            font-weight: bold;
            color: green;
        }
    </style>
</head>
<body>
    <h2>Edit Admin Details</h2>

    <form method="post">
        <label>Username:</label><br>
        <input type="text" name="username" value="<?= htmlspecialchars($username) ?>"><br><br>

        <label>New Password:</label><br>
        <input type="password" name="password"><br><br>

        <input type="submit" value="Update">
    </form>

    <p><?= $message ?></p>
</body>
</html>
