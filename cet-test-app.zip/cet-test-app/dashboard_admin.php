<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
$adminName = $_SESSION['admin_name'];
include 'db.php';

$subjects = ['physics', 'chemistry', 'maths', 'biology'];
$counts = [];
$tests = [];

foreach ($subjects as $sub) {
    // Count total questions
    $res = $conn->query("SELECT COUNT(*) as total FROM tests WHERE subject='$sub'");
    $data = $res->fetch_assoc();
    $counts[$sub] = $data['total'];

    // // Count distinct test numbers
    $res2 = $conn->query("SELECT COUNT(DISTINCT test_number) as test_count FROM tests WHERE subject='$sub'");
    $data2 = $res2->fetch_assoc();
    $tests[$sub] = $data2['test_count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - CET</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            background-color: #f4f6f9;
        }

        .sidebar {
            width: 220px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
            height: 100vh;
        }

        .sidebar h2 {
            text-align: center;
            font-size: 22px;
            margin-bottom: 30px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 20px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            font-size: 15px;
        }

        .sidebar ul li a:hover {
            text-decoration: underline;
        }

        .main-content {
            flex: 1;
            padding: 25px;
            background-color: #ecf0f1;
        }

        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #ccc;
            padding-bottom: 10px;
        }

        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 30px;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.2s, box-shadow 0.3s;
        }

        .card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 16px rgba(0,0,0,0.15);
        }

        .card h3 {
            margin-top: 0;
            color: #007bff;
        }

        .card a {
            color: #2c3e50;
            text-decoration: none;
            font-weight: bold;
            display: block;
            margin-bottom: 6px;
        }

        .card a:hover {
            text-decoration: underline;
        }

        .quick-links {
            margin-top: 50px;
        }

        .quick-links h3 {
            margin-bottom: 15px;
        }

        .quick-links ul {
            list-style: none;
            padding: 0;
        }

        .quick-links li {
            margin: 10px 0;
        }

        .quick-links li a {
            color: #007bff;
            text-decoration: none;
        }

        .quick-links li a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }

            .main-content {
                padding: 15px;
            }

            header {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>

<div class="sidebar">
    <h2>CET Admin</h2>
        <ul>
    <li><a href="dashboard_admin.php">🏠 Dashboard</a></li>
    <li><a href="edit_admin.php">🔐 Update Password</a></li>
    <li><a href="manage_students.php">👨‍🎓 Manage Students</a></li>
    <li><a href="manage_admins.php">🧑‍💼 Manage Admins</a></li>
    <li><a href="upload_test.php">📝 Upload Test Questions</a></li>
    <li><a href="uploadpaper.php">📄 Upload Paper</a></li>
    <li><a href="view_submissions.php">📊 View Scores</a></li>
    <li><a href="add_subjects.php">➕ Add Subjects</a></li>
    <li><a href="tests_list.php?subject=<?= $sub ?>">🧪 Manage Tests</a></li>
    <li><a href="logout.php">🚪 Logout</a></li>

    </ul>
</div>

<div class="main-content">
    <header>
        <h1>Welcome, <?= htmlspecialchars($adminName) ?> 👋</h1>
        <p><?= date('d M Y, h:i A') ?></p>
    </header>

    <section class="dashboard">
        <?php foreach ($subjects as $sub): ?>
            <div class="card">
                <h3><?= ucfirst($sub) ?> CET</h3>
                <a href="view_questions.php?subject=<?= $sub ?>">👁 View Questions</a>
                <a href="upload_test.php?subject=<?= $sub ?>">📝 Upload Questions</a>
                <a href="view_tests.php?subject=<?= $sub ?>">📄 View Tests</a>
                <p>Total Questions: <strong><?= $counts[$sub] ?></strong></p>
                <p>Total Tests: <strong><?= $tests[$sub] ?></strong></p>
            </div>
        <?php endforeach; ?>
    </section>

    <section class="quick-links">
        <h3>Quick Actions</h3>
        <ul>
            <li><a href="add_subjects.php">➕ Add Subjects</a></li>
            <li><a href="upload_test.php">📝 Add Questions</a></li>
            <li><a href="manage_students.php">👨‍🎓 Manage Students</a></li>
            <li><a href="manage_admins.php">🧑‍💼 Manage Admins</a></li>
        </ul>
    </section>
</div>

</body>
</html>
