<?php
session_start();
include 'db.php'; // Your database connection

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Find by email OR name
    $stmt = $conn->prepare("SELECT * FROM students WHERE email = ? OR name = ?");
    $stmt->bind_param("ss", $username, $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['student'] = $row['id'];
            $_SESSION['student_name'] = $row['name'];
            header("Location: dashboard_student.php");
            exit();
        } else {
            $error = "❌ Incorrect password.";
        }
    } else {
        $error = "❌ No student found with that email or name.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Student Login - CET App</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>

    <form method="POST" action="">
        <h2>Student Login</h2>

        <?php if ($error): ?>
            <p style="color: red; font-weight: bold;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <label>Email or Username:</label><br>
        <input type="text" name="username" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Login</button>
    </form>

</body>
</html>
