<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

$subjects = $conn->query("SELECT * FROM subjects");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Select Subject - Admin</title>
    <style>
        body { font-family: Arial; background: #f7f7f7; padding: 20px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 20px; }
        .card {
            background: #fff; padding: 20px; border-radius: 10px; text-align: center;
            box-shadow: 0 0 10px rgba(0,0,0,0.1); transition: transform 0.2s;
        }
        .card:hover { transform: translateY(-5px); }
        a { text-decoration: none; color: #3498db; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Select a Subject to Upload Tests</h2>
    <div class="grid">
        <?php while ($row = $subjects->fetch_assoc()): ?>
            <div class="card">
                <h3><?= ucfirst($row['name']) ?></h3>
                <a href="admin_tests.php?subject=<?= urlencode($row['name']) ?>">Manage Tests</a>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>
