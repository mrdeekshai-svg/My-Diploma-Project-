<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

// Fetch all subjects
$subjects = $conn->query("SELECT * FROM subjects");

// Handle URL query params for prefill
$selectedSubject = $_GET['subject'] ?? '';
$selectedTest = $_GET['test'] ?? '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = $_POST['subject'];
    $test_number = (int)$_POST['test_number'];
    $question = $_POST['question'];
    $option1 = $_POST['option1'];
    $option2 = $_POST['option2'];
    $option3 = $_POST['option3'];
    $option4 = $_POST['option4'];
    $correct_input = strtoupper(trim($_POST['correct']));

    // Convert correct option (A/B/C/D) to 1/2/3/4
    $correct_option = match($correct_input) {
        'A' => 1,
        'B' => 2,
        'C' => 3,
        'D' => 4,
        default => 0
    };

    if ($correct_option === 0) {
        die("<script>alert('❌ Invalid correct option. Must be A, B, C, or D.'); window.history.back();</script>");
    }

    // Insert into DB
    $stmt = $conn->prepare("INSERT INTO tests (subject, test_number, question, option1, option2, option3, option4, correct_option)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sisssssi", $subject, $test_number, $question, $option1, $option2, $option3, $option4, $correct_option);
    if (!$stmt->execute()) {
        die("Execute failed: " . $stmt->error);
    }

    $stmt->close();
    echo "<script>alert('✅ Question uploaded successfully!'); window.location.href='upload_test.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Upload CET Question</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            padding: 20px;
        }
        .form-box {
            background: #fff;
            padding: 25px;
            max-width: 600px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 15px;
        }
        input[type="text"], textarea, select, input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #2980b9;
        }
        .back-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 8px 16px;
            background-color: #2ecc71;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .back-btn:hover {
            background-color: #27ae60;
        }
    </style>
</head>
<body>
<a href="dashboard_admin.php" class="back-btn">&larr; Back to Dashboard</a>

<div class="form-box">
    <h2>Upload CET Question</h2>
    <form method="POST">
        <label for="subject">Subject:</label>
        <?php if (!empty($selectedSubject)): ?>
            <input type="text" name="subject" value="<?= htmlspecialchars($selectedSubject) ?>" readonly>
        <?php else: ?>
            <select name="subject" id="subject" required>
                <option value="">-- Select Subject --</option>
                <?php while ($row = $subjects->fetch_assoc()): ?>
                    <option value="<?= $row['name'] ?>"><?= ucfirst($row['name']) ?></option>
                <?php endwhile; ?>
            </select>
        <?php endif; ?>

        <label for="test_number">Test Number:</label>
        <input type="number" name="test_number" id="test_number" min="1" required value="<?= htmlspecialchars($selectedTest) ?>">

        <label for="question">Question:</label>
        <textarea name="question" id="question" rows="4" required></textarea>

        <label for="option1">Option A:</label>
        <input type="text" name="option1" id="option1" required>

        <label for="option2">Option B:</label>
        <input type="text" name="option2" id="option2" required>

        <label for="option3">Option C:</label>
        <input type="text" name="option3" id="option3" required>

        <label for="option4">Option D:</label>
        <input type="text" name="option4" id="option4" required>

        <label for="correct">Correct Option (A/B/C/D):</label>
        <input type="text" name="correct" id="correct" maxlength="1" pattern="[ABCDabcd]" required>

        <button type="submit">Upload Question</button>
    </form>
</div>
</body>
</html>
