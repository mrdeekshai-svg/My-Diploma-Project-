<?php
session_start();

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    include 'db.php';

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($admin_id, $admin_username, $hashed_password);
        $stmt->fetch();

      if (password_verify($password, $hashed_password)) {
    $_SESSION['admin'] = $admin_id;                   // Admin ID
    $_SESSION['admin_name'] = $admin_username;        // Admin Name (username)
    $_SESSION['is_super_admin'] = ($admin_id == 1);   // Super admin flag
    header("Location: dashboard_admin.php");
    exit();
}
 else {
            $error = "❌ Incorrect password.";
        }
    } else {
        $error = "❌ Admin username not found.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - CET App</title>
    <link rel="stylesheet" href="login_style.css">
</head>
<body>
<div class="login-box">
    <h2>Admin Login</h2>
    <?php if (!empty($error)): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Login</button>
    </form>
    <p class="note">Access restricted to authorized admins only.<br>
    </p>
</div>
</body>
</html>
