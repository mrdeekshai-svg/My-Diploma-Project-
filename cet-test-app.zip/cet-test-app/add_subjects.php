<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

// Add subject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
    $name = trim($_POST['subject']);
    if (!empty($name)) {
        $stmt = $conn->prepare("INSERT INTO subjects (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $stmt->close();
        $message = "✅ Subject '$name' added successfully!";
    } else {
        $message = "⚠️ Subject name cannot be empty.";
    }
}

// Edit subject
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_subject'])) {
    $id = (int) $_POST['subject_id'];
    $new_name = trim($_POST['new_name']);
    if (!empty($new_name)) {
        $stmt = $conn->prepare("UPDATE subjects SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $new_name, $id);
        $stmt->execute();
        $stmt->close();
        $message = "✏️ Subject name updated successfully!";
    }
}

// Toggle status
if (isset($_GET['toggle'])) {
    $id = (int) $_GET['toggle'];
    $conn->query("UPDATE subjects SET status = IF(status='active','inactive','active') WHERE id=$id");
    header("Location: add_subjects.php");
    exit();
}

// Delete subject
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $conn->query("DELETE FROM subjects WHERE id=$id");
    header("Location: add_subjects.php");
    exit();
}

$subjects = $conn->query("SELECT * FROM subjects ORDER BY name ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Subjects</title>
  <style>
    body { font-family: Arial; background: #f0f0f0; padding: 20px; }
    .box { background: #fff; padding: 20px; max-width: 700px; margin: auto; border-radius: 10px; box-shadow: 0 0 10px #ccc; }
    h2 { text-align: center; }
    form { margin-bottom: 20px; }
    input[type="text"] { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px; }
    button { padding: 10px 20px; border: none; background: #3498db; color: white; border-radius: 5px; cursor: pointer; }
    button:hover { background: #2980b9; }
    .back-btn { display: inline-block; margin-bottom: 15px; background: #2ecc71; text-decoration: none; padding: 8px 15px; color: white; border-radius: 5px; }
    .back-btn:hover { background: #27ae60; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    th, td { padding: 10px; border: 1px solid #ccc; text-align: left; }
    .actions a { margin-right: 8px; text-decoration: none; padding: 4px 8px; border-radius: 4px; }
    .edit-btn { background: #f1c40f; color: #fff; }
    .toggle-btn { background: #27ae60; color: #fff; }
    .delete-btn { background: #e74c3c; color: #fff; }
    .message { color: green; font-weight: bold; margin-bottom: 10px; }
  </style>
</head>
<body>
<div class="box">
  <a class="back-btn" href="dashboard_admin.php">← Back to Dashboard</a>

  <h2>Manage Subjects</h2>

  <?php if (isset($message)): ?>
    <p class="message"><?= $message ?></p>
  <?php endif; ?>

  <form method="POST">
    <input type="text" name="subject" placeholder="Enter new subject name" required>
    <button type="submit" name="add_subject">Add Subject</button>
  </form>

  <table>
    <tr>
      <th>Subject</th>
      <th>Status</th>
      <th>Actions</th>
    </tr>
    <?php while ($row = $subjects->fetch_assoc()): ?>
    <tr>
      <td>
        <form method="POST" style="display:flex; gap:10px; align-items:center;">
          <input type="hidden" name="subject_id" value="<?= $row['id'] ?>">
          <input type="text" name="new_name" value="<?= htmlspecialchars($row['name']) ?>">
          <button type="submit" name="edit_subject">Save</button>
        </form>
      </td>
      <td><?= ucfirst($row['status']) ?></td>
      <td class="actions">
        <a class="toggle-btn" href="?toggle=<?= $row['id'] ?>">Toggle</a>
        <a class="delete-btn" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this subject?')">Delete</a>
      </td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
