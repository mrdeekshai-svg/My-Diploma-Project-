<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

include 'db.php';

// Get question ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Invalid question ID.";
    exit();
}

$question_id = intval($_GET['id']);
$success = '';
$error = '';

// Fetch existing data
$stmt = $conn->prepare("SELECT * FROM tests WHERE id = ?");
$stmt->bind_param("i", $question_id);
$stmt->execute();
$result = $stmt->get_result();
$question = $result->fetch_assoc();
$stmt->close();

if (!$question) {
    echo "Question not found.";
    exit();
}

// Update form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question_text = trim($_POST['question']);
    $option1 = trim($_POST['option1']);
    $option2 = trim($_POST['option2']);
    $option3 = trim($_POST['option3']);
    $option4 = trim($_POST['option4']);
    $correct_option = intval($_POST['correct_option']);

    if ($question_text && $option1 && $option2 && $option3 && $option4 && in_array($correct_option, [1, 2, 3, 4])) {
        $update = $conn->prepare("UPDATE tests SET question = ?, option1 = ?, option2 = ?, option3 = ?, option4 = ?, correct_option = ? WHERE id = ?");
        $update->bind_param("ssssiii", $question_text, $option1, $option2, $option3, $option4, $correct_option, $question_id);
        if ($update->execute()) {
            $success = "✅ Question updated successfully.";
            // Reload updated values
            $question['question'] = $question_text;
            $question['option1'] = $option1;
            $question['option2'] = $option2;
            $question['option3'] = $option3;
            $question['option4'] = $option4;
            $question['correct_option'] = $correct_option;
        } else {
            $error = "❌ Failed to update question.";
        }
        $update->close();
    } else {
        $error = "Please fill all fields correctly.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Question</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #eef2f7;
            padding: 30px;
        }
        .form-box {
            background: white;
            max-width: 600px;
            margin: auto;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input[type="text"], select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }
        .submit-btn {
            margin-top: 20px;
            background-color: #27ae60;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
        }
        .submit-btn:hover {
            background-color: #219150;
        }
        .back-btn {
            display: inline-block;
            margin-top: 15px;
            text-decoration: none;
            color: #3498db;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="form-box">
        <h2>Edit Question</h2>

        <?php if ($success): ?>
            <div class="success"><?= $success ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Question:</label>
            <input type="text" name="question" value="<?= htmlspecialchars($question['question']) ?>" required>

            <label>Option 1:</label>
            <input type="text" name="option1" value="<?= htmlspecialchars($question['option1']) ?>" required>

            <label>Option 2:</label>
            <input type="text" name="option2" value="<?= htmlspecialchars($question['option2']) ?>" required>

            <label>Option 3:</label>
            <input type="text" name="option3" value="<?= htmlspecialchars($question['option3']) ?>" required>

            <label>Option 4:</label>
            <input type="text" name="option4" value="<?= htmlspecialchars($question['option4']) ?>" required>

            <label>Correct Option (1 to 4):</label>
            <select name="correct_option" required>
                <?php for ($i = 1; $i <= 4; $i++): ?>
                    <option value="<?= $i ?>" <?= $question['correct_option'] == $i ? 'selected' : '' ?>><?= $i ?></option>
                <?php endfor; ?>
            </select>

            <button type="submit" class="submit-btn">Update Question</button>
        </form>

        <a href="view_questions.php?subject=<?= urlencode($question['subject']) ?>" class="back-btn">← Back to Question List</a>
    </div>
</body>
</html>
