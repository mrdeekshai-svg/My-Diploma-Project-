<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}
include 'db.php';

$subject = $_GET['subject'] ?? '';
if (!$subject) die("Subject missing");

$test_numbers = $conn->query("SELECT DISTINCT test_number FROM tests WHERE subject='$subject' ORDER BY test_number ASC");
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= ucfirst($subject) ?> - Tests</title>
    <style>
        body { font-family: Arial; background: #f9f9f9; padding: 20px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 20px; }
        .card {
            background: #fff; padding: 15px; text-align: center;
            border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        a { text-decoration: none; color: #2c3e50; font-weight: bold; }
        .add { background: #dff0d8; padding: 12px; border-radius: 10px; text-align: center; }
    </style>
</head>
<body>
    <h2><?= ucfirst($subject) ?> - Test Sets</h2>
    <div class="grid">
        <?php while ($row = $test_numbers->fetch_assoc()): ?>
            <div class="card">
                <h4>Test <?= $row['test_number'] ?></h4>
                <a href="upload_question.php?subject=<?= urlencode($subject) ?>&test=<?= $row['test_number'] ?>">➕ Upload Questions</a>
            </div>
        <?php endwhile; ?>
        <!-- Add new test -->
        <?php
        $next = $conn->query("SELECT IFNULL(MAX(test_number),0)+1 AS next FROM tests WHERE subject='$subject'");
        $nextTest = $next->fetch_assoc()['next'];
        ?>
        <div class="add">
            <a href="upload_question.php?subject=<?= urlencode($subject) ?>&test=<?= $nextTest ?>">➕ Add Test <?= $nextTest ?></a>
        </div>
    </div>
</body>
</html>
