<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location:admin_login.php");
    exit();
}

include 'db.php'; // Include your DB connection

// Delete a student if requested
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM students WHERE id = $id");
    header("Location: manage_students.php");
    exit();
}

// Get all students
$students = $conn->query("SELECT * FROM students ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Students</title>
    <link rel="stylesheet" href="manage_students.css">
</head>
<body>
    <div class="container">
        <h2>Manage Students</h2>
        <a class="btn-add" href="add_student.php">+ Add New Student</a>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $students->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td>
                        <a class="edit" href="edit_student.php?id=<?= $row['id'] ?>">Edit</a>
                        <a class="delete" href="?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this student?')">Delete</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <div class="back-button">
    <a href="dashboard_admin.php">⬅ Back to Admin Dashboard</a>
</div>
</body>
</html>
