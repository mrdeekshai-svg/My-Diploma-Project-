<?php
session_start();

if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$student_id = $_SESSION['student'];
$student_name = $_SESSION['student_name'];

$query = "
    SELECT subject, score, attempted_at 
    FROM test_attempts 
    WHERE student_id = '$student_id'
    ORDER BY subject, attempted_at DESC
";

$result = $conn->query($query);

$results = [];

while ($row = $result->fetch_assoc()) {
    $subject = ucfirst($row['subject']);
    $results[$subject][] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Results</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f4f8;
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: auto;
        }

        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 10px rgba(0,0,0,0.1);
        }

        .card h3 {
            color: #007bff;
            margin-bottom: 10px;
        }

        .card table {
            width: 100%;
            border-collapse: collapse;
        }

        .card table td {
            padding: 8px;
            border-bottom: 1px solid #eee;
        }

        .logout-btn {
            text-align: center;
            margin-top: 40px;
        }

        .logout-btn a {
            padding: 10px 20px;
            background-color: #dc3545;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<h2>Welcome <?= htmlspecialchars($student_name) ?>! Here are your Results</h2>

<div class="card-container">
    <?php foreach ($results as $subject => $attempts): ?>
        <div class="card">
            <h3><?= $subject ?></h3>
            <table>
                <?php foreach ($attempts as $attempt): ?>
                    <tr>
                        <td><strong>Score:</strong></td>
                        <td><?= htmlspecialchars($attempt['score']) ?></td>
                    </tr>
                    <tr>
                        <td><strong>Attempted:</strong></td>
                        <td><?= htmlspecialchars($attempt['attempted_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    <?php endforeach; ?>
</div>

<div class="logout-btn">
    <a href="logout.php">Logout</a>
</div>

</body>
</html>
