<?php
session_start();
if (!isset($_SESSION['student'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$student_id = $_SESSION['student'];
$student_name = $_SESSION['student_name'];

// Validate POST data
if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    !isset($_POST['subject'], $_POST['test_number'], $_POST['answers']) ||
    !is_array($_POST['answers'])
) {
    echo "Invalid submission.";
    exit();
}

$subject = strtolower(trim($_POST['subject']));
$test_number = (int)$_POST['test_number'];
$answers = $_POST['answers'];

// Check if already attempted
$check = $conn->prepare("SELECT id FROM test_attempts WHERE student_id = ? AND subject = ? AND test_number = ?");
$check->bind_param("isi", $student_id, $subject, $test_number);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    $check->close();
    echo "<h3 style='color:red;text-align:center;'>❌ You have already submitted this test.</h3>
          <div style='text-align:center;margin-top:20px;'>
              <a class='result-btn' href='dashboard_student.php'>&larr; Back to Dashboard</a>
          </div>";
    exit();
}
$check->close();

// Get total number of questions in this test
$total_result = $conn->prepare("SELECT COUNT(*) FROM tests WHERE subject = ? AND test_number = ?");
$total_result->bind_param("si", $subject, $test_number);
$total_result->execute();
$total_result->bind_result($total_questions);
$total_result->fetch();
$total_result->close();

$score = 0;
$answered = 0;

// Fetch correct answers only for answered questions
$ids = implode(',', array_map('intval', array_keys($answers)));
$query = "SELECT id, correct_option FROM tests WHERE id IN ($ids) AND subject = '$subject' AND test_number = $test_number";
$result = $conn->query($query);

$correct_answers = [];
while ($row = $result->fetch_assoc()) {
    $correct_answers[$row['id']] = $row['correct_option'];
}

// Calculate score
foreach ($answers as $question_id => $selected_option) {
    if (isset($correct_answers[$question_id])) {
        $answered++;
        if ((int)$selected_option === (int)$correct_answers[$question_id]) {
            $score++;
        }
    }
}

$wrong = $answered - $score;
$unanswered = $total_questions - $answered;

// Insert result into DB
$stmt = $conn->prepare("INSERT INTO test_attempts (student_id, subject, test_number, score, total_questions, answered_questions, attempted_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
$stmt->bind_param("isiiii", $student_id, $subject, $test_number, $score, $total_questions, $answered);
$stmt->execute();
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Test Submitted</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f9ff;
            text-align: center;
            padding: 40px;
        }
        .result-container {
            max-width: 600px;
            margin: 40px auto;
            background: #fdfefe;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
            animation: slideUpFade 0.8s ease;
        }
        .result-container h2 {
            text-align: center;
            color: #2d3436;
            margin-bottom: 25px;
            font-size: 24px;
            font-weight: 600;
        }
        .fancy-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            text-align: center;
            transition: all 0.4s ease;
        }
        .fancy-table th,
        .fancy-table td {
            padding: 14px 18px;
            background: #f0f4f8;
            color: #2d3436;
            border-radius: 10px;
            font-size: 16px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.04);
            transition: background 0.3s ease;
        }
        .fancy-table th {
            background: #dfe6e9;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .fancy-table tr:hover td {
            background: #dfe6e9;
        }
        .result-btn {
            display: inline-block;
            margin-top: 25px;
            padding: 10px 22px;
            background: #0984e3;
            color: #fff;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transition: background 0.3s, transform 0.3s;
        }
        .result-btn:hover {
            background: #74b9ff;
            transform: translateY(-2px);
        }
        @keyframes slideUpFade {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="result-container">
    <h2>✅ Test Submitted Successfully!</h2>

    <table class="fancy-table">
        <thead>
            <tr>
                <th>Total</th>
                <th>Answered</th>
                <th>Correct</th>
                <th>Wrong</th>
                <th>Unanswered</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= $total_questions ?></td>
                <td><?= $answered ?></td>
                <td><?= $score ?></td>
                <td><?= $wrong ?></td>
                <td><?= $unanswered ?></td>
            </tr>
        </tbody>
    </table>

    <a class="result-btn" href="dashboard_student.php">&larr; Back to Dashboard</a>
</div>

</body>
</html>
